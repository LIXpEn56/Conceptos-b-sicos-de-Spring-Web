package com.example.login.controller;

import com.example.login.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador encargado de manejar las solicitudes de inicio de sesión.
 */
@Controller
public class LoginController {

    // GET: muestra el formulario de inicio
    @GetMapping("/inicio")
    public String showLoginForm(Model model,
                                @RequestParam(value = "error", required = false) String error) {
        model.addAttribute("user", new User());
        if (error != null) {
            model.addAttribute("errorMessage", "Usuario o contraseña incorrectos.");
        }
        return "login";
    }

    // POST: valida las credenciales
    @PostMapping("/inicio")
    public String login(@ModelAttribute("User") User user, Model model) {
        // Validación ficticia (usuario: admin, contraseña: 1234)
        if ("admin".equals(user.getUsername()) && "1234".equals(user.getPassword())) {
            model.addAttribute("username", user.getUsername());
            return "home";
        } else {
            return "redirect:/inicio?error=true";
        }
    }
}

